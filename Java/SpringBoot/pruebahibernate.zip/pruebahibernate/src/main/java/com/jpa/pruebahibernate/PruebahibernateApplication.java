package com.jpa.pruebahibernate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebahibernateApplication {

	public static void main(String[] args) {
		SpringApplication.run(PruebahibernateApplication.class, args);
	}

}
